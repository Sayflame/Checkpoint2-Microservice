import { Injectable } from '@angular/core';
import {Tarefa} from '../interfaces/Tarefa';

@Injectable({
  providedIn: 'root'
})
export class TarefaService {
  constructor() { }

  //Esta lista virá da API
  tarefas:Tarefa[] = [
    {id: "L11111", titulo: "Luis", descricao: "Tarefas do Luis", dataDeVencimento: "01/05"},
    {id: "V22222", titulo: "Vinicius", descricao: "Tarefas do Vini", dataDeVencimento: "02/05"},
  ];

  listar():Tarefa[]{
    return this.tarefas;
  }

  remover(id:string){
    const tarefa = this.tarefas.find(t => t.id == id);

    if(tarefa){
       const index = this.tarefas.indexOf(tarefa);
       this.tarefas.splice(index,1);
    }
  }

  adicionar(Tarefa:Tarefa){
    this.tarefas.push(Tarefa);
  }
}
