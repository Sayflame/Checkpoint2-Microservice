export interface Tarefa{
  id:string;
  titulo:string;
  descricao:string;
  dataDeVencimento:string;
}
