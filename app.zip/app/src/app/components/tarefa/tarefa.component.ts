import { TarefaService } from './../../services/tarefa.service';
import { Tarefa } from './../../interfaces/Tarefa';
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {ReactiveFormsModule  } from '@angular/forms';

@Component({
  selector: 'app-tarefa',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './tarefa.component.html',
  styleUrl: './tarefa.component.css'
})
export class TarefaComponent {
    tarefas:Tarefa[] = [];
    tarefaForm: FormGroup = new FormGroup({})

   constructor(private TarefaService:TarefaService, private formBuilder: FormBuilder) {
      this.tarefaForm = this.formBuilder.group({
        nome: ['', Validators.required],
        telefone: ['', Validators.required]
      })
  }

  generateRandomString(length: number): string  {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = ''
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  inserir(){
     if(this.tarefaForm.valid) {
        const tarefaNovo: Tarefa = {
          titulo: this.tarefaForm.value.titulo,
          descricao: this.tarefaForm.value.descricao,
          dataDeVencimento: this.tarefaForm.value.dataDeVencimento,
          id : this.generateRandomString(6)
        }
        this.tarefaForm.reset()
        this.TarefaService.adicionar(tarefaNovo)
        alert('Cadastrado com sucesso!')
     }
  }

  listar():void{
      this.tarefas = this.TarefaService.listar();
  }

  remover(id: string):void{
    this.TarefaService.remover(id);
    alert("Removido com sucesso!")
  }


  ngOnInit():void{
    this.listar();
  }

};

